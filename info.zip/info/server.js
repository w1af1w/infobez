const express = require('express');
const { DatabaseSync } = require('node:sqlite');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const app = express();
const PORT = 3000;
// Подключение к базе данных
const db = new DatabaseSync('./bd_info.db');
// Загружаем список распространённых паролей
const commonPasswords = fs
    .readFileSync('./common-passwords.txt', 'utf8')
    .split('\n')
    .map(password => password.trim().toLowerCase())
    .filter(password => password !== '');
// Позволяем серверу принимать JSON
app.use(express.json());
// Раздаём HTML, CSS и JavaScript
app.use(express.static(__dirname));
// НАСТРОЙКИ ЗАЩИТЫ ОТ ПЕРЕБОРА ПАРОЛЕЙ
// Максимальное количество неправильных попыток
const MAX_ATTEMPTS = 3;
// Время блокировки — 1 минута
const BLOCK_TIME = 60 * 1000;
// Здесь храним информацию о попытках входа
const loginAttempts = new Map();
// ФУНКЦИЯ УЧЁТА НЕПРАВИЛЬНЫХ ПОПЫТОК
function registerFailedAttempt(login) {
    const currentTime = Date.now();
    let attempt = loginAttempts.get(login);
    // Если это первая неправильная попытка
    if (!attempt) {
        attempt = {
            count: 0,
            blocked: false,
            lastAttempt: currentTime
        };
    }
    // Увеличиваем количество неправильных попыток
    attempt.count++;
    // Запоминаем время последней попытки
    attempt.lastAttempt = currentTime;
    // Если достигли 3 попыток — блокируем вход
    if (attempt.count >= MAX_ATTEMPTS) {
        attempt.blocked = true;
    }
    // Сохраняем информацию
    loginAttempts.set(login, attempt);
}
// РЕГИСТРАЦИЯ
app.post('/register', async (req, res) => {
    const { login, password } = req.body;
    // Проверяем заполнение полей
    if (!login || !password) {
        return res.status(400).json({
            message: 'Заполните все поля'
        });
    }
    // ПРОВЕРКА ПАРОЛЯ
    const passwordErrors = [];
    // Минимум 8 символов
    if (password.length < 8) {
        passwordErrors.push(
            '• минимум 8 символов'
        );
    }
    // Должна быть заглавная буква
    if (!/[A-Z]/.test(password)) {
        passwordErrors.push('• хотя бы одна заглавная буква A-Z');
    }
    // Должна быть строчная буква
    if (!/[a-z]/.test(password)) {
        passwordErrors.push('• хотя бы одна строчная буква a-z');
    }
    // Должна быть цифра
    if (!/[0-9]/.test(password)) {
        passwordErrors.push('• хотя бы одна цифра');
    }
    // Должен быть специальный символ
    if (!/[@#$%^&*!]/.test(password)) {
        passwordErrors.push('• хотя бы один специальный символ: @ # $ % ^ & * !');
    }
    // Проверяем пароль по списку распространённых паролей
    if (commonPasswords.includes(password.toLowerCase())) {
        passwordErrors.push('• пароль не должен быть распространённым');
    }
    // Если есть хотя бы одна ошибка
    if (passwordErrors.length > 0) {
        return res.status(400).json({
            message:
                'Пароль должен соответствовать требованиям:\n' +
                passwordErrors.join('\n')
        });
    }
    // РАБОТА С БАЗОЙ ДАННЫХ
    try {
        // Проверяем, существует ли пользователь
        const checkUser = db.prepare(`
            SELECT id
            FROM users
            WHERE login = ?
        `);
        const user = checkUser.get(login);
        // Если такой пользователь уже существует
        if (user) {
            return res.status(400).json({
                message: 'Такой логин уже существует'
            });
        }
        // ХЭШИРОВАНИЕ ПАРОЛЯ
        const passwordHash = await bcrypt.hash(password,10);
        // ДОБАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯ
        const insertUser = db.prepare(`
            INSERT INTO users (login, password_hash)
            VALUES (?, ?)
        `);
        insertUser.run(
            login,
            passwordHash
        );
        // Сообщение об успешной регистрации
        res.json({
            message: 'Регистрация успешна!'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: 'Ошибка сервера'
        });
    }
});
// ВХОД
app.post('/login', async (req, res) => {
    const { login, password } = req.body;
    // Проверяем заполнение
    if (!login || !password) {
        return res.status(400).json({
            message: 'Введите логин и пароль'
        });
    }
    // ПРОВЕРКА БЛОКИРОВКИ
    const attempt = loginAttempts.get(login);
    if (attempt) {
        const currentTime = Date.now();
        // Сколько времени прошло с последней попытки
        const timePassed = currentTime - attempt.lastAttempt;
        // Если пользователь заблокирован
        // и минута ещё не прошла
        if (
            attempt.blocked &&
            timePassed < BLOCK_TIME
        ) {
            // Сколько секунд осталось
            const secondsLeft = Math.ceil(
                (BLOCK_TIME - timePassed) / 1000
            );
            return res.status(429).json({
                message:
                    'Слишком много неправильных попыток.\n' +
                    `Попробуйте снова через ${secondsLeft} секунд.`
            });
        }
        // Если минута прошла
        // снимаем блокировку
        if (timePassed >= BLOCK_TIME) {
            loginAttempts.delete(login);
        }
    }
    // ПРОВЕРКА ЛОГИНА И ПАРОЛЯ
    try {
        // Ищем пользователя в базе
        const findUser = db.prepare(`
            SELECT *
            FROM users
            WHERE login = ?
        `);
        const user = findUser.get(login);
        // ЕСЛИ ПОЛЬЗОВАТЕЛЬ НЕ НАЙДЕН
        if (!user) {
            // Засчитываем неправильную попытку
            registerFailedAttempt(login);
            return res.status(401).json({message: 'Неверный логин или пароль'});
        }
        // ПРОВЕРКА ПАРОЛЯ
        const passwordCorrect = await bcrypt.compare(password, user.password_hash);
        // ЕСЛИ ПАРОЛЬ НЕПРАВИЛЬНЫЙ
        if (!passwordCorrect) {
            // Засчитываем неправильную попытку
            registerFailedAttempt(login);
            return res.status(401).json({
                message: 'Неверный логин или пароль'
            });
        }
        // УСПЕШНЫЙ ВХОД
        // Сбрасываем счётчик неправильных попыток
        loginAttempts.delete(login);
        res.json({
            message: 'Вход выполнен успешно!'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Ошибка сервера'});
    }
});
// ЗАПУСК СЕРВЕРА
app.listen(PORT, () => {
    console.log(`Сервер запущен: http://localhost:${PORT}`);
});